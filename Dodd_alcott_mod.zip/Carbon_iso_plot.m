figure

subplot(3,4,1)
plot(run1.state.time,run1.state.isoprox)
xlabel('Time (Ma)')
ylabel('isoprox (d13C)')
ylim([-5 10])


subplot(3,4,2)
plot(run1.state.time,run1.state.isodist)
xlabel('Time (Ma)')
ylabel('isodist (d13C)')
ylim([-5 10])

subplot(3,4,3)
plot(run1.state.time,run1.state.isosurf)
xlabel('Time (Ma)')
ylabel('isosurf (d13C)')
ylim([-5 10])

subplot(3,4,4)
plot(run1.state.time,run1.state.Aiso)
xlabel('Time (Ma)')
ylabel('Aiso (d13C)')
ylim([-5 10])

subplot(3,4,5)
plot(run1.state.time,run1.state.Prum)
xlabel('Time (Ma)')
ylabel('Prox (uM)')

subplot(3,4,6)
plot(run1.state.time,run1.state.Dium)
xlabel('Time (Ma)')
ylabel('Dist (uM)')

subplot(3,4,7)
plot(run1.state.time,run1.state.Pd)
xlabel('Time (Ma)')
ylabel('Pr/Dp (uM)')

subplot(3,4,8)
plot(run1.state.time,run1.state.Dpum)
xlabel('Time (Ma)')
ylabel('Deep (uM)')

subplot(3,4,9)
plot(run1.state.time,run1.state.PAL)
xlabel('Time (Ma)')
ylabel('O2 (PAL)')
set(gca, 'YScale', 'log')
xlim([-3.5e9 -1.9e9])

subplot(3,4,10)
plot(run1.state.time,run1.state.O2_D)
xlabel('Time (Ma)')
ylabel('O2_D (uM)')

subplot(3,4,11)
plot(run1.state.time,run1.state.O2_S)
xlabel('Time (Ma)')
ylabel('O2_S (uM)')

subplot(3,4,12)
plot(run1.state.time,run1.state.O2_DP)
xlabel('Time (Ma)')
ylabel('O2_DP (uM)')
