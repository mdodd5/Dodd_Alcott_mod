figure

subplot(5,3,1)
plot(run1.state.time,run1.state.PAL)
xlabel('Time (Ma)')
ylabel('O_{2} (PAL)')
set(gca, 'YScale', 'log')

subplot(5,3,2)
plot(run1.state.time,run1.state.Fsilw)
xlabel('TGime (Ma)')
ylabel('Fsilw')

subplot(5,3,3)
plot(run1.state.time,run1.state.River_SRP)
xlabel('TGime (Ma)')
ylabel('P_{mol} (River input)')

subplot(5,3,4)
plot(run1.state.time,run1.state.Fcarbw)
xlabel('TGime (Ma)')
ylabel('Fcarbw')

subplot(5,3,5)
plot(run1.state.time,run1.state.fanoxicdist)
xlabel('TGime (Ma)')
ylabel('fanoxic_{dist}')

subplot(5,3,6)
plot(run1.state.time,run1.state.CO2atm)
xlabel('TGime (Ma)')
ylabel('seq ')
ylim([0 1e10])

subplot(5,3,7)
plot(run1.state.time,run1.state.forg)
xlabel('TGime (Ma)')
ylabel('Organic burial_{mol}')

subplot(5,3,8)
plot(run1.state.time,run1.state.C)
xlabel('TGime (Ma)')
ylabel('Cc reservoir')

subplot(5,3,9)
plot(run1.state.time,run1.state.D)
xlabel('TGime (Ma)')
ylabel('Degas ')

subplot(5,3,10)
plot(run1.state.time,run1.state.Dpum)
xlabel('TGime (Ma)')
ylabel('Deep_P uM ')

subplot(5,3,11)
plot(run1.state.time,run1.state.Fmocb)
xlabel('TGime (Ma)')
ylabel('mocb ')

subplot(5,3,12)
plot(run1.state.time,run1.state.EXPOSED)
xlabel('TGime (Ma)')
ylabel('Cont ')

subplot(5,3,13)
plot(run1.state.time,run1.state.Atmos_Weather)
xlabel('TGime (Ma)')
ylabel('O2 weather ')

subplot(5,3,14)
plot(run1.state.time,run1.state.FrgfO2)
xlabel('TGime (Ma)')
ylabel('red gas ')

subplot(5,3,15)
plot(run1.state.time,run1.state.SRP_DP)
xlabel('TGime (Ma)')
ylabel('P prox to dist ')

